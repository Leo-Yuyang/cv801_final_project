# CV801 complete experiment dossier

This archive is the detailed, evidence-backed companion to the concise CV801
report. It was generated from retained experiment artifacts at
`2026-11-18T12:24:21+00:00` without launching new GPU work.

## Start here

- `CV801_Experimental_Dossier.pdf`: long-form experimental record.
- `README_zh.md`: Chinese reading guide.
- `experiment_inventory.md`: canonical scientific experiment inventory.
- `experiment_records/`: one YAML-frontmatter Markdown record per experiment.
- `experiment_ledger.csv`: all discoverable Slurm attempts, including failed,
  cancelled, repair, and superseded work.
- `training_curves/`: machine-readable histories.
- `figures/`: deterministic plots used by the PDF.
- `source_data/`: sanitised copies of the canonical source artifacts.
- `numeric_evidence.json`: numeric provenance index.
- `MANIFEST.sha256`: package checksums (added during packaging).

## Interpretation rules

Scheduler status and scientific-result status are separate. Some inference jobs
ended with a scheduler failure after producing complete outputs; those outputs
were retained only when the corrected output-level audit passed. Validation and
Golden Test metrics are also separate. Missing values were never guessed.

The raw public YOLO26x base checkpoint did not receive a matched Golden Test
evaluation, so this dossier does not claim a numerical pre/post fine-tuning gain.
