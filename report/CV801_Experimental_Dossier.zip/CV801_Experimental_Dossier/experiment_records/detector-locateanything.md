---
experiment_id: "detector-locateanything"
title: "LocateAnything fine-tuning"
family: "detection"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# LocateAnything fine-tuning

## Objective

Fine-tune a localization model and evaluate it with the unified COCO and operating-point protocol on the sealed Golden Test.

## Configuration

- **job ID:** 357716
- **training steps/epochs:** 3000
- **runtime seconds:** 19134.8799
- **prediction policy:** constant_0.2_no_native_confidence; operating threshold=0.2 includes all decoded boxes; generation_order_ties

## Results

- **COCO AP@[.50:.95]:** 0.5332954278012827
- **AP50:** 0.6180303872858958
- **precision:** 0.8528610354223434
- **recall:** 0.7166571265025758
- **F1:** 0.7788491446345257
- **mean matched IoU:** 0.9495854879594187

## Interpretation and boundaries

This result is a post-fine-tuning Golden Test measurement. It must not be interpreted as a matched pre/post gain because the raw public base checkpoint was not evaluated under the same sealed protocol.

## Source artifacts

- `wkdrs/cv801-golden-test/final_summary.complete.json`
- `wkdrs/cv801-locateanything/train-357716/trainer_state.json`
- `wkdrs/cv801-locateanything/slurm-cv801-locany-357716.out`

## Missing or unavailable telemetry

Energy consumption was not recorded. Raw-base matched Golden Test metrics are unavailable.
