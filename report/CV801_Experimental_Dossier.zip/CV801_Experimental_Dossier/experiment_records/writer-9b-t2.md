---
experiment_id: "writer-9b-t2"
title: "Qwen3.5-9B Writer T2"
family: "writer"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Qwen3.5-9B Writer T2

## Objective

Measure in-domain Writer adaptation with detector boxes.

## Configuration

- **writer size:** 9B
- **variant:** T2
- **training:** LoRA fine-tuning
- **job ID:** 382484
- **max length:** 6144

## Results

- **JSON valid rate:** 0.995
- **schema valid rate:** 0.995
- **exact object count:** 0.641
- **object-link F1:** 0.7667731629392971
- **caption token F1:** 0.5130207561367792
- **independent visual total:** 4.175
- **unsupported claim share:** 0.3316963372211991

## Interpretation and boundaries

Small-model failures are retained as experimental results. An undefined object-link F1 means the structured output did not provide a valid denominator; it is not replaced by zero.

## Source artifacts

- `docs/mds/cv801-release/writer_scale_results.csv`
- `wkdrs/cv801-qwen35/t2-train-382484/v0-20261109-131602/checkpoint-1197/trainer_state.json`
- `wkdrs/cv801-qwen35/t2-train-382484/v0-20261109-131602/checkpoint-1197/args.json`

## Missing or unavailable telemetry

Per-sample human preference judgments were cancelled by project decision.
