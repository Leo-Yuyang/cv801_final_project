---
experiment_id: "dataset-protocol"
title: "Dataset preparation and sealed Golden Test"
family: "data"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Dataset preparation and sealed Golden Test

## Objective

Establish the immutable data and evaluation contract used by all comparable systems.

## Configuration

- **images:** 8097
- **annotated objects:** 14601
- **Golden Test images:** 1000
- **split policy:** fixed project split; Golden Test kept separate from training

## Results

- **status:** complete
- **metric contracts:** COCO bbox, structured Writer, and independent visual rubric

## Interpretation and boundaries

The 8,097-image, 14,601-object corpus is the accepted project corpus. The detailed report does not substitute the discarded 2,000 unsuitable images into any denominator.

## Source artifacts

- `wkdrs/cv801-golden-test/final_summary.complete.json`
- `datas/cv801_detection_v1`
- `datas/cv801_vlm_v1`

## Missing or unavailable telemetry

Original acquisition timestamps and manual cleaning time were not recorded in machine-readable experiment telemetry.
