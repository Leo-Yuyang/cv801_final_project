---
experiment_id: "writer-4b-t2"
title: "Qwen3.5-4B Writer T2"
family: "writer"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Qwen3.5-4B Writer T2

## Objective

Measure in-domain Writer adaptation with detector boxes.

## Configuration

- **writer size:** 4B
- **variant:** T2
- **training:** LoRA fine-tuning
- **job ID:** 443920
- **max length:** 6144

## Results

- **JSON valid rate:** 0.052
- **schema valid rate:** 0.052
- **exact object count:** 0.045
- **object-link F1:** 0.05777777777777777
- **caption token F1:** 0.4547934409007228
- **independent visual total:** 4.630566801619433
- **unsupported claim share:** 0.33686905632772496

## Interpretation and boundaries

Small-model failures are retained as experimental results. An undefined object-link F1 means the structured output did not provide a valid denominator; it is not replaced by zero.

## Source artifacts

- `docs/mds/cv801-release/writer_scale_results.csv`
- `wkdrs/cv801-qwen35/t2-train-443920/v0-20261115-095220/checkpoint-1197/trainer_state.json`
- `wkdrs/cv801-qwen35/t2-train-443920/v0-20261115-095220/checkpoint-1197/args.json`

## Missing or unavailable telemetry

Per-sample human preference judgments were cancelled by project decision.
