# CV801 dossier task packet

Build an additive, evidence-traceable experiment dossier containing the long-form PDF, standardized experiment records, complete execution ledger, training histories, source evidence, checksums, and a public GitHub ZIP. Do not run new GPU experiments or invent missing telemetry.
