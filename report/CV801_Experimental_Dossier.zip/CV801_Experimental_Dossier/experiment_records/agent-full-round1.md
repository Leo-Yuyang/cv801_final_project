---
experiment_id: "agent-full-round1"
title: "Full review and revision round 1"
family: "agent-review"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Full review and revision round 1

## Objective

Measure the effect of the specified reviewer/revision configuration on the common T2 Writer output.

## Configuration

- **configuration:** full_round1
- **samples:** 1000
- **base writer:** Qwen3.5-9B T2

## Results

- **schema valid rate:** 0.912
- **object-link F1:** 0.7085463842220598
- **caption token F1:** 0.5126982280096823
- **independent visual total:** 4.288
- **unsupported claims:** 1305

## Interpretation and boundaries

Revision can change structural and semantic metrics in different directions; the report therefore preserves both structured-output and independent-image evaluations.

## Source artifacts

- `wkdrs/cv801-golden-test/final_summary.complete.json`
- `wkdrs/cv801-golden-test/efficiency.json`

## Missing or unavailable telemetry

Direct GPT-6 Astra review was cancelled and is not represented by this replacement experiment.
