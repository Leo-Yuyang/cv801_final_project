---
experiment_id: "grid-4b-low"
title: "Writer 4B with low-tier reviewer"
family: "writer-reviewer-grid"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Writer 4B with low-tier reviewer

## Objective

Populate the controlled Writer-size by reviewer-tier factorial grid.

## Configuration

- **Writer:** 4B
- **reviewer tier:** low
- **paired samples:** 1000
- **bootstrap iterations:** 10000
- **seed:** 20261104

## Results

- **independent visual total:** 3.196
- **object id link f1:** not recorded
- **schema valid rate:** 0.0
- **unsupported claim share:** 0.48765822784810126

## Interpretation and boundaries

The cell is interpreted jointly with paired contrasts and confidence intervals. Undefined structured metrics remain undefined.

## Source artifacts

- `wkdrs/cv801-writer-reviewer-statistics/paired_analysis.json`
- `wkdrs/cv801-writer-reviewer-statistics/repair_lineage.json`
- `wkdrs/cv801-writer-scale-analysis/reviewer_grid_status.current.csv`

## Missing or unavailable telemetry

No manual preference score was collected.
