---
experiment_id: "writer-2b-t1"
title: "Qwen3.5-2B Writer T1"
family: "writer"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Qwen3.5-2B Writer T1

## Objective

Measure in-domain Writer adaptation without detector boxes.

## Configuration

- **writer size:** 2B
- **variant:** T1
- **training:** LoRA fine-tuning
- **job ID:** 443976
- **max length:** 4096

## Results

- **JSON valid rate:** 0.0
- **schema valid rate:** 0.0
- **exact object count:** 0.0
- **object-link F1:** not recorded
- **caption token F1:** not recorded
- **independent visual total:** 3.5877862595419847
- **unsupported claim share:** 0.32924050632911395

## Interpretation and boundaries

Small-model failures are retained as experimental results. An undefined object-link F1 means the structured output did not provide a valid denominator; it is not replaced by zero.

## Source artifacts

- `docs/mds/cv801-release/writer_scale_results.csv`
- `wkdrs/cv801-qwen35/t1-train-443976/v0-20261115-112827/checkpoint-1197/trainer_state.json`
- `wkdrs/cv801-qwen35/t1-train-443976/v0-20261115-112827/checkpoint-1197/args.json`

## Missing or unavailable telemetry

Per-sample human preference judgments were cancelled by project decision.
