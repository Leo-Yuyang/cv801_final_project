# Dossier story

The dossier records the complete evidence chain from data and localization through Writer adaptation, review/revision, factorial scale analysis, and release. It is an audit-oriented experiment record rather than a new submission manuscript.
