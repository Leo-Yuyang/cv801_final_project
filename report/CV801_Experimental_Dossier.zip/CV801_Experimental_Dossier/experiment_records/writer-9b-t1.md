---
experiment_id: "writer-9b-t1"
title: "Qwen3.5-9B Writer T1"
family: "writer"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Qwen3.5-9B Writer T1

## Objective

Measure in-domain Writer adaptation without detector boxes.

## Configuration

- **writer size:** 9B
- **variant:** T1
- **training:** LoRA fine-tuning
- **job ID:** 358388
- **max length:** 4096

## Results

- **JSON valid rate:** 0.888
- **schema valid rate:** 0.888
- **exact object count:** 0.529
- **object-link F1:** 0.596958174904943
- **caption token F1:** 0.49141701542132254
- **independent visual total:** 4.172
- **unsupported claim share:** 0.3021829776796664

## Interpretation and boundaries

Small-model failures are retained as experimental results. An undefined object-link F1 means the structured output did not provide a valid denominator; it is not replaced by zero.

## Source artifacts

- `docs/mds/cv801-release/writer_scale_results.csv`
- `wkdrs/cv801-qwen35/t1-train-358388/v0-20261104-192033/checkpoint-1197/trainer_state.json`
- `wkdrs/cv801-qwen35/t1-train-358388/v0-20261104-192033/checkpoint-1197/args.json`

## Missing or unavailable telemetry

Per-sample human preference judgments were cancelled by project decision.
