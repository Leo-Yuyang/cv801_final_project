---
experiment_id: "detector-yolo26x"
title: "YOLO26x fine-tuning"
family: "detection"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# YOLO26x fine-tuning

## Objective

Fine-tune a localization model and evaluate it with the unified COCO and operating-point protocol on the sealed Golden Test.

## Configuration

- **job ID:** 357714
- **training steps/epochs:** 89
- **runtime seconds:** 5144.400000000001
- **prediction policy:** native_model_score; AP conf=0.001; nms_iou=0.7; operating threshold=0.404 selected on validation F1 curve

## Results

- **COCO AP@[.50:.95]:** 0.7288467921417757
- **AP50:** 0.822074012826154
- **precision:** 0.7608225108225108
- **recall:** 0.8048082427017744
- **F1:** 0.7821974965229485
- **mean matched IoU:** 0.9429569775965781

## Interpretation and boundaries

This result is a post-fine-tuning Golden Test measurement. It must not be interpreted as a matched pre/post gain because the raw public base checkpoint was not evaluated under the same sealed protocol.

## Source artifacts

- `wkdrs/cv801-golden-test/final_summary.complete.json`
- `wkdrs/cv801-yolo26x/train-357714/results.csv`
- `wkdrs/cv801-yolo26x/slurm-cv801-yolo26x-357714.out`

## Missing or unavailable telemetry

Energy consumption was not recorded. Raw-base matched Golden Test metrics are unavailable.
