---
experiment_id: "detector-grounding-dino"
title: "Grounding DINO fine-tuning"
family: "detection"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Grounding DINO fine-tuning

## Objective

Fine-tune a localization model and evaluate it with the unified COCO and operating-point protocol on the sealed Golden Test.

## Configuration

- **job ID:** 357715
- **training steps/epochs:** 4800
- **runtime seconds:** 3931.9588
- **prediction policy:** native_model_score; AP box/text threshold=0.01; nms_iou=0.6; operating threshold=0.25091278553009033 selected on validation micro-F1

## Results

- **COCO AP@[.50:.95]:** 0.264745175557883
- **AP50:** 0.2815405717308357
- **precision:** 0.22537960954446853
- **recall:** 0.594733829421866
- **F1:** 0.3268837501966336
- **mean matched IoU:** 0.9712199072762904

## Interpretation and boundaries

This result is a post-fine-tuning Golden Test measurement. It must not be interpreted as a matched pre/post gain because the raw public base checkpoint was not evaluated under the same sealed protocol.

## Source artifacts

- `wkdrs/cv801-golden-test/final_summary.complete.json`
- `wkdrs/cv801-grounding-dino/train-357715/checkpoint-4800/trainer_state.json`
- `wkdrs/cv801-grounding-dino/slurm-cv801-gdino-357715.out`

## Missing or unavailable telemetry

Energy consumption was not recorded. Raw-base matched Golden Test metrics are unavailable.
