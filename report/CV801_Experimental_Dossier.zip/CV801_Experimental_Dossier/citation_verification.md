# Citation verification

This technical dossier reports repository experiments and contains no scholarly bibliography claims requiring external citation verification. Model names identify evaluated systems; all numerical claims resolve to packaged first-party experiment artifacts.

| Key | Citation or claim class | Verification source | Status |
|---|---|---|---|
| C0 | Absence of external scholarly citations | LaTeX source and bibliography audit | repository-verified |
| E1 | Numerical experiment claims | Packaged first-party source data and `numeric_evidence.json` | repository-verified |
