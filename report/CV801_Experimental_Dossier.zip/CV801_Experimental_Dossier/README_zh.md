# CV801 完整实验档案阅读指南

本压缩包是现有精简报告的补充，不替换原报告。生成时间为
2026-11-18T16:24:21+04:00（UAE，UTC+4），生成过程没有重新启动 GPU 实验。

建议先阅读 `CV801_Experimental_Dossier.pdf`，再按需查看：

1. `experiment_inventory.md`：科学实验清单；
2. `experiment_records/`：每个实验的标准化记录；
3. `experiment_ledger.csv`：全部可发现的 Slurm 尝试，包括 smoke、失败、超时、修复和正式运行；
4. `training_curves/`：训练 loss、eval loss 等逐步数据；
5. `source_data/` 与 `numeric_evidence.json`：结果来源及数值证据；
6. `MANIFEST.sha256`：压缩包内文件校验值。

阅读时请区分“调度任务状态”和“科研结果状态”。少数推理任务在产出完整文件后因收尾审计退出为 FAILED；只有通过修正后输出审计的结果才被接受。训练验证集与封存 Golden Test 的指标也不能混用。

本项目没有在相同 Golden Test 协议下评估原始 YOLO26x 公共权重，因此报告只陈述微调后性能，不虚构微调前后增益。人工评分和直接 GPT-6 Astra 实验已按用户决定取消，并在档案中显式登记为未运行。
