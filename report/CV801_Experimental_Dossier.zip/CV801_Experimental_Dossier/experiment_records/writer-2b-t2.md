---
experiment_id: "writer-2b-t2"
title: "Qwen3.5-2B Writer T2"
family: "writer"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Qwen3.5-2B Writer T2

## Objective

Measure in-domain Writer adaptation with detector boxes.

## Configuration

- **writer size:** 2B
- **variant:** T2
- **training:** LoRA fine-tuning
- **job ID:** 443911
- **max length:** 6144

## Results

- **JSON valid rate:** 0.001
- **schema valid rate:** 0.001
- **exact object count:** 0.001
- **object-link F1:** 0.0
- **caption token F1:** 0.3125
- **independent visual total:** 3.505
- **unsupported claim share:** 0.4104368932038835

## Interpretation and boundaries

Small-model failures are retained as experimental results. An undefined object-link F1 means the structured output did not provide a valid denominator; it is not replaced by zero.

## Source artifacts

- `docs/mds/cv801-release/writer_scale_results.csv`
- `wkdrs/cv801-qwen35/t2-train-443911/v0-20261115-093448/checkpoint-1197/trainer_state.json`
- `wkdrs/cv801-qwen35/t2-train-443911/v0-20261115-093448/checkpoint-1197/args.json`

## Missing or unavailable telemetry

Per-sample human preference judgments were cancelled by project decision.
