#!/usr/bin/env bash
set -euo pipefail
latexmk -pdf -interaction=nonstopmode -halt-on-error -file-line-error main.tex
cp -f main.pdf CV801_Experimental_Dossier.pdf
