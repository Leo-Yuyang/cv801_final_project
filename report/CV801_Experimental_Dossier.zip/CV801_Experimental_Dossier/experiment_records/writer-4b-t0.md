---
experiment_id: "writer-4b-t0"
title: "Qwen3.5-4B Writer T0"
family: "writer"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Qwen3.5-4B Writer T0

## Objective

Measure the zero-shot Writer baseline.

## Configuration

- **writer size:** 4B
- **variant:** T0
- **training:** zero-shot
- **job ID:** not applicable
- **max length:** base inference configuration

## Results

- **JSON valid rate:** 0.694
- **schema valid rate:** 0.0
- **exact object count:** 0.043
- **object-link F1:** 0.2707856598016781
- **caption token F1:** 0.16732103552860908
- **independent visual total:** 3.0781563126252505
- **unsupported claim share:** 0.44580114627460754

## Interpretation and boundaries

Small-model failures are retained as experimental results. An undefined object-link F1 means the structured output did not provide a valid denominator; it is not replaced by zero.

## Source artifacts

- `docs/mds/cv801-release/writer_scale_results.csv`

## Missing or unavailable telemetry

Per-sample human preference judgments were cancelled by project decision.
