# CV801 experiment inventory

Generated: 2026-11-18T12:24:21+00:00

| Family | Records |
|---|---:|
| agent-review | 6 |
| cancelled | 2 |
| data | 1 |
| detection | 3 |
| statistics | 1 |
| writer | 10 |
| writer-reviewer-grid | 9 |

## Records

| Experiment ID | Title | Family | Status |
|---|---|---|---|
| `dataset-protocol` | Dataset preparation and sealed Golden Test | data | complete |
| `detector-yolo26x` | YOLO26x fine-tuning | detection | complete |
| `detector-grounding-dino` | Grounding DINO fine-tuning | detection | complete |
| `detector-locateanything` | LocateAnything fine-tuning | detection | complete |
| `writer-2b-t0` | Qwen3.5-2B Writer T0 | writer | complete |
| `writer-2b-t1` | Qwen3.5-2B Writer T1 | writer | complete |
| `writer-2b-t2` | Qwen3.5-2B Writer T2 | writer | complete |
| `writer-4b-t0` | Qwen3.5-4B Writer T0 | writer | complete |
| `writer-4b-t1` | Qwen3.5-4B Writer T1 | writer | complete |
| `writer-4b-t2` | Qwen3.5-4B Writer T2 | writer | complete |
| `writer-9b-t0` | Qwen3.5-9B Writer T0 | writer | complete |
| `writer-9b-t1` | Qwen3.5-9B Writer T1 | writer | complete |
| `writer-9b-t2` | Qwen3.5-9B Writer T2 | writer | complete |
| `writer-27b-t0` | Qwen3.5-27B zero-shot Writer | writer | complete |
| `agent-rc` | Crop reviewer only | agent-review | complete |
| `agent-rd` | Disease reviewer only | agent-review | complete |
| `agent-rc-rd` | Combined crop and disease reviewers | agent-review | complete |
| `agent-full-round1` | Full review and revision round 1 | agent-review | complete |
| `agent-full-round2` | Full review and revision round 2 | agent-review | complete |
| `agent-pixtral-visual-reviewer` | Reviewer-family replacement with Pixtral | agent-review | complete |
| `grid-2b-low` | Writer 2B with low-tier reviewer | writer-reviewer-grid | complete |
| `grid-2b-mid` | Writer 2B with mid-tier reviewer | writer-reviewer-grid | complete |
| `grid-2b-high` | Writer 2B with high-tier reviewer | writer-reviewer-grid | complete |
| `grid-4b-low` | Writer 4B with low-tier reviewer | writer-reviewer-grid | complete |
| `grid-4b-mid` | Writer 4B with mid-tier reviewer | writer-reviewer-grid | complete |
| `grid-4b-high` | Writer 4B with high-tier reviewer | writer-reviewer-grid | complete |
| `grid-9b-low` | Writer 9B with low-tier reviewer | writer-reviewer-grid | complete |
| `grid-9b-mid` | Writer 9B with mid-tier reviewer | writer-reviewer-grid | complete |
| `grid-9b-high` | Writer 9B with high-tier reviewer | writer-reviewer-grid | complete |
| `statistics-paired-bootstrap` | Paired bootstrap and interaction analysis | statistics | complete |
| `cancelled-human-rating` | Cancelled manual engineer rating | cancelled | cancelled |
| `cancelled-gpt6-astra` | Cancelled direct GPT-6 Astra evaluation | cancelled | cancelled |
