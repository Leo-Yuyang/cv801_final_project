---
experiment_id: "agent-rd"
title: "Disease reviewer only"
family: "agent-review"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Disease reviewer only

## Objective

Measure the effect of the specified reviewer/revision configuration on the common T2 Writer output.

## Configuration

- **configuration:** rd
- **samples:** 1000
- **base writer:** Qwen3.5-9B T2

## Results

- **schema valid rate:** 0.956
- **object-link F1:** 0.7171052631578948
- **caption token F1:** 0.5088397589747438
- **independent visual total:** 4.218
- **unsupported claims:** 1262

## Interpretation and boundaries

Revision can change structural and semantic metrics in different directions; the report therefore preserves both structured-output and independent-image evaluations.

## Source artifacts

- `wkdrs/cv801-golden-test/final_summary.complete.json`
- `wkdrs/cv801-golden-test/efficiency.json`

## Missing or unavailable telemetry

Direct GPT-6 Astra review was cancelled and is not represented by this replacement experiment.
