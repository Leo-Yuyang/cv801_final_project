---
experiment_id: "statistics-paired-bootstrap"
title: "Paired bootstrap and interaction analysis"
family: "statistics"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Paired bootstrap and interaction analysis

## Objective

Quantify paired Writer, reviewer, and interaction contrasts over the same 1,000 images.

## Configuration

- **paired samples:** 1000
- **bootstrap iterations:** 10000
- **seed:** 20261104
- **interval:** percentile 95% paired image-cluster bootstrap CI

## Results

- **metrics:** independent_visual_total, object_id_link_f1, schema_valid_rate, unsupported_claim_share
- **primary interaction families:** gap-closure contrasts

## Interpretation and boundaries

Confidence intervals apply to the paired resampling protocol declared in the source JSON; they are not independent-run variance estimates.

## Source artifacts

- `wkdrs/cv801-writer-reviewer-statistics/paired_analysis.json`

## Missing or unavailable telemetry

Independent random-seed retraining variance was not measured.
