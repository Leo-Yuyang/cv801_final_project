---
experiment_id: "agent-rc-rd"
title: "Combined crop and disease reviewers"
family: "agent-review"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Combined crop and disease reviewers

## Objective

Measure the effect of the specified reviewer/revision configuration on the common T2 Writer output.

## Configuration

- **configuration:** rc_rd
- **samples:** 1000
- **base writer:** Qwen3.5-9B T2

## Results

- **schema valid rate:** 0.956
- **object-link F1:** 0.6764907470870458
- **caption token F1:** 0.500769776772077
- **independent visual total:** 4.139
- **unsupported claims:** 1254

## Interpretation and boundaries

Revision can change structural and semantic metrics in different directions; the report therefore preserves both structured-output and independent-image evaluations.

## Source artifacts

- `wkdrs/cv801-golden-test/final_summary.complete.json`
- `wkdrs/cv801-golden-test/efficiency.json`

## Missing or unavailable telemetry

Direct GPT-6 Astra review was cancelled and is not represented by this replacement experiment.
