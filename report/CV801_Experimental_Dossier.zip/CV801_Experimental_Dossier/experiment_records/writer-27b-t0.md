---
experiment_id: "writer-27b-t0"
title: "Qwen3.5-27B zero-shot Writer"
family: "writer"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Qwen3.5-27B zero-shot Writer

## Objective

Test whether parameter scale alone substitutes for in-domain Writer adaptation.

## Configuration

- **writer size:** 27B
- **variant:** zero-shot
- **fine-tuning:** none
- **samples:** 1000

## Results

- **JSON valid rate:** 0.984
- **object-link F1:** 0.7199124726477025
- **caption token F1:** 0.22248608106454928
- **ROUGE-L:** 0.1744113962763245

## Interpretation and boundaries

The 27B result is a scale control, not a trained alternative. It shows that parameter count alone did not replace domain adaptation in this experiment.

## Source artifacts

- `wkdrs/cv801-golden-test/final_summary.complete.json`
- `wkdrs/cv801-golden-test/efficiency.json`

## Missing or unavailable telemetry

No 27B fine-tuned model was trained.
