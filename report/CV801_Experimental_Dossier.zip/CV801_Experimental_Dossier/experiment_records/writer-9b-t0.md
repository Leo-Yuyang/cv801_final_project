---
experiment_id: "writer-9b-t0"
title: "Qwen3.5-9B Writer T0"
family: "writer"
status: "complete"
scientific_result: "available"
generated_utc: "2026-11-18T12:24:21+00:00"
timezone: "UAE (UTC+4)"
---

# Qwen3.5-9B Writer T0

## Objective

Measure the zero-shot Writer baseline.

## Configuration

- **writer size:** 9B
- **variant:** T0
- **training:** zero-shot
- **job ID:** not applicable
- **max length:** base inference configuration

## Results

- **JSON valid rate:** 0.976
- **schema valid rate:** 0.0
- **exact object count:** 0.572
- **object-link F1:** 0.4885799404170804
- **caption token F1:** 0.05760269670107007
- **independent visual total:** 2.65
- **unsupported claim share:** 0.6192492238216201

## Interpretation and boundaries

Small-model failures are retained as experimental results. An undefined object-link F1 means the structured output did not provide a valid denominator; it is not replaced by zero.

## Source artifacts

- `docs/mds/cv801-release/writer_scale_results.csv`

## Missing or unavailable telemetry

Per-sample human preference judgments were cancelled by project decision.
