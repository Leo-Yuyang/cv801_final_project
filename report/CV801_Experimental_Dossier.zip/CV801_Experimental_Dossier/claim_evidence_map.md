# Claim--evidence map

| Claim family | Canonical evidence | Boundary | Status |
|---|---|---|---|
| Detector performance | `source_data/final_summary.json` | Post-fine-tuning Golden Test only | verified |
| Writer structure and language | `source_data/writer_results.csv` | Reviewed targets and independent visual audit are distinct | verified |
| Review/revision | `source_data/final_summary.json` | Scheduler state does not determine scientific validity | verified |
| Scale grid | `source_data/paired_analysis.json` | Paired bootstrap, not retraining variance | verified |
| Runtime | `source_data/efficiency.json`, ledger | Queue time excluded where stated | verified |
